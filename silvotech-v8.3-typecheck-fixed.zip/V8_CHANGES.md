# SilvoTech v8 — manufacturing capabilities

- Replaced the legacy `/[lang]/oferta` redirect with a page describing seven example manufacturing groups and the parameters needed for a quotation. No unverified numerical specifications or certifications were added.
- Kept all existing homepage image and video paths, and every file under `public/` unchanged. Kept the same Nunito font configuration.
- Added a visible homepage enquiry button and capabilities link, plus links from product cards to the relevant section and from each section to an enquiry with the product group preselected.
- Completed visible DE, CZ and SK copy that previously inherited English, as well as EN content that inherited Polish. Localised the form choices and privacy page in all five languages.
- Corrected the document's HTML language for each locale, added offer and privacy metadata, and included the offer page in the sitemap.
- Improved file upload visibility and linked the required privacy acknowledgement to the policy. Surfaced the existing conditions for 24-hour dispatch and product-specific documentation.
- Preserved the video file and poster, while respecting the visitor's reduced-motion preference.

See `README.md` for deployment and SMTP verification. Publishing the ZIP to a repository alone does not change DNS or the live site.

## V8.1 deployment fix
- Replaced the active “Produkcja indywidualna” photograph with the newly supplied image.
- Removed the redundant `app/(root)` redirect route. The existing middleware still redirects `/` to the preferred language, while avoiding the Next.js 15.5.x missing `page_client-reference-manifest.js` build-trace error on Vercel.

## V8.2 content cleanup
- Simplified the homepage video hero to the central main title only.
- Changed the “Produkcja indywidualna” image to `object-fit: contain` so the full photograph remains visible.
- Removed the 24-hour stock qualification note and the certification-scope disclaimer from rendered pages.
- Removed the NIP number from the footer, contact content, company data and privacy-policy copy.

## V8.3 type-check correction
- Removed the four remaining localized `docs.note` override fields after the note property was removed from `SiteCopy`.
